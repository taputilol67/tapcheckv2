package dev.tapcheck.plugin.api;

import org.bukkit.entity.Player;

public final class TapCheckBlacklistEvent extends TapCheckEvent {
    private final Player player;
    public TapCheckBlacklistEvent(Player player) { this.player = player; }
    public Player getPlayer() { return player; }
}