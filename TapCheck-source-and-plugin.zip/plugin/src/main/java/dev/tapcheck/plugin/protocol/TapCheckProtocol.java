package dev.tapcheck.plugin.protocol;

public final class TapCheckProtocol {
    public static final int VERSION = 1;
    public static final String CHANNEL = "tapcheck:main";
    public static final String HELLO = "HELLO";
    public static final String RESPONSE = "RESPONSE";
    public static final String MOD_LIST = "MOD_LIST";
    public static final String STATUS = "STATUS";
    public static final String LOG_REQUEST = "LOG_REQUEST";
    public static final String LOG_BEGIN = "LOG_BEGIN";
    public static final String LOG_CHUNK = "LOG_CHUNK";
    public static final String LOG_END = "LOG_END";
    public static final String LOG_ERROR = "LOG_ERROR";

    private TapCheckProtocol() {}
}