package dev.tapcheck.plugin.verification;

public record ReportedMod(String id, String name, String version, String loader) {
    public ReportedMod {
        id = id == null ? "" : id;
        name = name == null ? id : name;
        version = version == null ? "unknown" : version;
        loader = loader == null ? "unknown" : loader;
    }
}