package dev.tapcheck.plugin;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.google.gson.Gson;
import dev.tapcheck.plugin.api.*;
import dev.tapcheck.plugin.protocol.TapCheckProtocol;
import dev.tapcheck.plugin.verification.ReportedMod;
import dev.tapcheck.plugin.verification.TapCheckSession;
import dev.tapcheck.plugin.verification.TapCheckStatus;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class TapCheckPlugin extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private static final Gson GSON = new Gson();
    private final Map<UUID, TapCheckSession> sessions = new ConcurrentHashMap<>();
    private Path logRoot;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        logRoot = getDataFolder().toPath().resolve("logs");
        try {
            Files.createDirectories(logRoot);
        } catch (IOException exception) {
            getLogger().severe("Unable to create the TapCheck log directory: " + exception.getMessage());
        }
        getServer().getMessenger().registerIncomingPluginChannel(this, TapCheckProtocol.CHANNEL, this::onPluginMessage);
        getServer().getMessenger().registerOutgoingPluginChannel(this, TapCheckProtocol.CHANNEL);
        getServer().getPluginManager().registerEvents(this, this);
        TapCheckAPI.bind(this);
        if (getCommand("tapcheck") != null) {
            getCommand("tapcheck").setExecutor(this);
            getCommand("tapcheck").setTabCompleter(this);
        }
        Bukkit.getScheduler().runTaskTimer(this, this::tickRewards, 20L, 20L);
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, this::purgeOldLogs, 20L * 60L * 30L, 20L * 60L * 30L);
        getLogger().info("TapCheck enabled. Client verification is optional by default.");
    }

    @Override
    public void onDisable() {
        getServer().getMessenger().unregisterIncomingPluginChannel(this, TapCheckProtocol.CHANNEL);
        getServer().getMessenger().unregisterOutgoingPluginChannel(this, TapCheckProtocol.CHANNEL);
        sessions.clear();
    }

    public TapCheckSession session(UUID uuid) {
        return sessions.get(uuid);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (!getConfig().getBoolean("settings.enabled", true)) return;
        Player player = event.getPlayer();
        String challenge = UUID.randomUUID().toString();
        TapCheckSession session = new TapCheckSession(player.getUniqueId(), challenge);
        session.originalListName(player.getPlayerListName());
        sessions.put(player.getUniqueId(), session);
        JsonObject hello = new JsonObject();
        hello.addProperty("action", TapCheckProtocol.HELLO);
        hello.addProperty("protocol", TapCheckProtocol.VERSION);
        hello.addProperty("challenge", challenge);
        hello.addProperty("serverVersion", getDescription().getVersion());
        hello.addProperty("logsEnabled", getConfig().getBoolean("logs.enabled", true));
        send(player, hello);

        long timeout = Math.max(1, getConfig().getLong("settings.handshake-timeout-seconds", 10)) * 20L;
        Bukkit.getScheduler().runTaskLater(this, () -> {
            TapCheckSession current = sessions.get(player.getUniqueId());
            if (current == null || current != session || current.status() != TapCheckStatus.VERIFYING) return;
            current.status(TapCheckStatus.NOT_VERIFIED);
            player.sendMessage(message("not-verified"));
            if (getConfig().getBoolean("verification.require-mod", false) && !isWhitelisted(player)) {
                player.kickPlayer(color("&cTapCheck is required on this server."));
            }
        }, timeout);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        TapCheckSession session = sessions.remove(event.getPlayer().getUniqueId());
        if (session != null) session.status(TapCheckStatus.DISCONNECTED);
    }

    private void onPluginMessage(String channel, Player player, byte[] bytes) {
        if (!TapCheckProtocol.CHANNEL.equals(channel) || bytes.length > 512_000) return;
        final JsonObject message;
        try {
            message = JsonParser.parseString(new String(bytes, StandardCharsets.UTF_8)).getAsJsonObject();
        } catch (RuntimeException exception) {
            getLogger().warning("Ignored malformed TapCheck message from " + player.getName());
            return;
        }
        TapCheckSession session = sessions.get(player.getUniqueId());
        if (session == null) return;
        String action = string(message, "action", "");
        if (TapCheckProtocol.RESPONSE.equals(action)) {
            if (!session.challenge().equals(string(message, "challenge", ""))) return;
            if (message.get("protocol") == null || message.get("protocol").getAsInt() != TapCheckProtocol.VERSION) return;
            session.responseReceived(true);
            session.clientVersion(string(message, "clientVersion", "unknown"));
            return;
        }
        if (TapCheckProtocol.MOD_LIST.equals(action)) {
            if (!session.responseReceived() || !session.challenge().equals(string(message, "challenge", ""))) return;
            List<ReportedMod> reported = new ArrayList<>();
            JsonArray mods = message.getAsJsonArray("mods");
            if (mods != null) {
                for (JsonElement element : mods) {
                    if (!element.isJsonObject()) continue;
                    JsonObject mod = element.getAsJsonObject();
                    ReportedMod item = new ReportedMod(
                            string(mod, "id", ""),
                            string(mod, "name", ""),
                            string(mod, "version", "unknown"),
                            string(mod, "loader", "fabric"));
                    reported.add(item);
                    Bukkit.getPluginManager().callEvent(new TapCheckModDetectedEvent(player, item));
                }
            }
            session.replaceMods(reported);
            boolean blacklisted = reported.stream().anyMatch(this::isBlacklisted);
            session.blacklisted(blacklisted);
            if (blacklisted) {
                session.status(getConfig().getBoolean("blacklist.deny-verification", true)
                        ? TapCheckStatus.FLAGGED : TapCheckStatus.VERIFIED);
                Bukkit.getPluginManager().callEvent(new TapCheckBlacklistEvent(player));
                notifyBlacklist(player, reported);
                if (getConfig().getBoolean("blacklist.kick", false)) {
                    player.kickPlayer(color("&eTapCheck detected a blacklisted mod."));
                    return;
                }
            } else {
                session.status(TapCheckStatus.VERIFIED);
                Bukkit.getPluginManager().callEvent(new TapCheckVerifyEvent(player));
                applyVerifiedSuffix(player, session);
                player.sendMessage(message("verified"));
            }
            sendStatus(player, session);
            return;
        }
        if (TapCheckProtocol.LOG_BEGIN.equals(action)) {
            if (!session.responseReceived() || !getConfig().getBoolean("logs.enabled", true)) return;
            if (!"latest.log".equals(string(message, "file", ""))) return;
            session.beginLog("latest.log");
            return;
        }
        if (TapCheckProtocol.LOG_CHUNK.equals(action)) {
            if (!"latest.log".equals(session.incomingLogName())) return;
            try {
                int sequence = message.get("sequence").getAsInt();
                byte[] chunk = Base64.getDecoder().decode(string(message, "data", ""));
                if (chunk.length <= 16_384) session.addLogChunk(sequence, chunk);
            } catch (RuntimeException ignored) {
                // Invalid chunks are discarded; the request can be retried by staff.
            }
            return;
        }
        if (TapCheckProtocol.LOG_END.equals(action) && "latest.log".equals(session.incomingLogName())) {
            byte[] data = session.finishLog();
            int maxBytes = Math.max(1, getConfig().getInt("logs.max-file-size-mb", 10)) * 1024 * 1024;
            if (data.length > maxBytes) {
                sendError(player, "The received log exceeded the configured size limit.");
                return;
            }
            Bukkit.getPluginManager().callEvent(new TapCheckLogReceivedEvent(player, writeLog(player, data)));
        }
    }

    private Path writeLog(Player player, byte[] data) {
        Path playerDirectory = logRoot.resolve(player.getUniqueId().toString());
        Path target = playerDirectory.resolve("latest.log").normalize();
        if (!target.startsWith(playerDirectory)) throw new IllegalStateException("Invalid log path");
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            try {
                Files.createDirectories(playerDirectory);
                Files.write(target, data, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
                JsonObject info = new JsonObject();
                info.addProperty("uuid", player.getUniqueId().toString());
                info.addProperty("name", player.getName());
                info.addProperty("lastUpdated", Instant.now().toString());
                Files.writeString(playerDirectory.resolve("player-info.json"), GSON.toJson(info),
                        StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            } catch (IOException exception) {
                getLogger().warning("Could not save log for " + player.getName() + ": " + exception.getMessage());
            }
        });
        return target;
    }

    private void sendStatus(Player player, TapCheckSession session) {
        JsonObject status = new JsonObject();
        status.addProperty("action", TapCheckProtocol.STATUS);
        status.addProperty("status", session.status().name());
        status.addProperty("challenge", session.challenge());
        send(player, status);
    }

    private void sendLogRequest(Player player, TapCheckSession session) {
        Bukkit.getPluginManager().callEvent(new TapCheckLogRequestEvent(player));
        JsonObject request = new JsonObject();
        request.addProperty("action", TapCheckProtocol.LOG_REQUEST);
        request.addProperty("challenge", session.challenge());
        request.addProperty("file", "latest.log");
        request.addProperty("maxBytes", Math.max(1, getConfig().getInt("logs.max-file-size-mb", 10)) * 1024 * 1024);
        send(player, request);
    }

    private void sendError(Player player, String error) {
        JsonObject response = new JsonObject();
        response.addProperty("action", TapCheckProtocol.LOG_ERROR);
        response.addProperty("message", error);
        send(player, response);
    }

    private void send(Player player, JsonObject object) {
        player.sendPluginMessage(this, TapCheckProtocol.CHANNEL, GSON.toJson(object).getBytes(StandardCharsets.UTF_8));
    }

    private void tickRewards() {
        if (!getConfig().getBoolean("rewards.enabled", true)) return;
        for (TapCheckSession session : sessions.values()) {
            Player player = Bukkit.getPlayer(session.uuid());
            if (player == null || session.status() != TapCheckStatus.VERIFIED || session.rewardsDisabled()) continue;
            session.addVerifiedSecond();
            for (String key : getConfig().getConfigurationSection("rewards.intervals") == null
                    ? Set.<String>of() : getConfig().getConfigurationSection("rewards.intervals").getKeys(false)) {
                String path = "rewards.intervals." + key;
                long interval = getConfig().getLong(path + ".interval", 0);
                if (interval <= 0 || session.verifiedSeconds() % interval != 0) continue;
                for (String command : getConfig().getStringList(path + ".commands")) {
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), replacePlaceholders(command, player));
                }
            }
        }
    }

    private String replacePlaceholders(String value, Player player) {
        return value.replace("%player%", player.getName())
                .replace("%uuid%", player.getUniqueId().toString())
                .replace("%displayname%", ChatColor.stripColor(player.getDisplayName()))
                .replace("%world%", player.getWorld().getName())
                .replace("%time%", Long.toString(System.currentTimeMillis() / 1000));
    }

    private boolean isBlacklisted(ReportedMod mod) {
        if (!getConfig().getBoolean("blacklist.enabled", true)) return false;
        for (String id : getConfig().getStringList("blacklist.mods")) {
            if (id.equalsIgnoreCase(mod.id())) return true;
        }
        for (Map<?, ?> entry : getConfig().getMapList("blacklist.entries")) {
            Object id = entry.get("id");
            if (id == null || !id.toString().equalsIgnoreCase(mod.id())) continue;
            Object versions = entry.get("versions");
            if (!(versions instanceof List<?> list) || list.isEmpty()) return true;
            for (Object version : list) {
                if ("*".equals(version.toString()) || version.toString().equalsIgnoreCase(mod.version())) return true;
            }
        }
        return false;
    }

    private boolean isWhitelisted(Player player) {
        return getConfig().getStringList("whitelist.players").stream()
                .anyMatch(value -> value.equalsIgnoreCase(player.getUniqueId().toString()));
    }

    private void applyVerifiedSuffix(Player player, TapCheckSession session) {
        if (!getConfig().getBoolean("verification.verified-suffix.enabled", true)) return;
        String suffix = getConfig().getString("verification.verified-suffix.value", " ✅");
        player.setPlayerListName(player.getName() + suffix);
    }

    private void notifyBlacklist(Player player, List<ReportedMod> mods) {
        if (!getConfig().getBoolean("blacklist.notify-staff", true)) return;
        String ids = mods.stream().filter(this::isBlacklisted).map(ReportedMod::id).distinct().sorted().toList().toString();
        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("tapcheck.admin") || staff.hasPermission("tapcheck.mods")) {
                staff.sendMessage(color("&e[TapCheck] &f" + player.getName() + " reported blacklisted mod(s): " + ids));
            }
        }
        getLogger().warning(player.getName() + " reported blacklisted mod(s): " + ids);
    }

    private void purgeOldLogs() {
        int retainDays = Math.max(0, getConfig().getInt("logs.retain-days", 30));
        long cutoff = System.currentTimeMillis() - retainDays * 86_400_000L;
        if (!Files.isDirectory(logRoot)) return;
        try (var paths = Files.walk(logRoot)) {
            paths.filter(Files::isRegularFile).filter(path -> {
                try { return Files.getLastModifiedTime(path).toMillis() < cutoff; }
                catch (IOException exception) { return false; }
            }).forEach(path -> {
                try { Files.deleteIfExists(path); } catch (IOException ignored) {}
            });
        } catch (IOException exception) {
            getLogger().warning("Could not purge old logs: " + exception.getMessage());
        }
    }

    private String message(String key) {
        return color(getConfig().getString("messages.prefix", "") + getConfig().getString("messages." + key, key));
    }

    private static String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }

    private static String string(JsonObject object, String key, String fallback) {
        JsonElement value = object.get(key);
        return value instanceof JsonPrimitive primitive && primitive.isString() ? primitive.getAsString()
                : value == null ? fallback : value.getAsString();
    }

    private Player findPlayer(String name) {
        Player online = Bukkit.getPlayerExact(name);
        return online != null ? online : Bukkit.getPlayer(name);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || "info".equalsIgnoreCase(args[0])) {
            sender.sendMessage(color("&bTapCheck &f" + getDescription().getVersion()
                    + " &7- optional client verification. Mod presence is not proof a player cannot cheat."));
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if ("reload".equals(sub)) {
            if (!sender.hasPermission("tapcheck.reload")) return noPermission(sender);
            reloadConfig();
            sender.sendMessage(color("&aTapCheck configuration reloaded."));
            return true;
        }
        if (args.length < 2 && Set.of("mods", "logs", "status", "clearlogs").contains(sub)) {
            sender.sendMessage(color("&cUsage: /tapcheck " + sub + " <player>"));
            return true;
        }
        if ("mods".equals(sub) || "status".equals(sub) || "logs".equals(sub)) {
            String permission = "mods".equals(sub) ? "tapcheck.mods" : "logs".equals(sub) ? "tapcheck.logs" : "tapcheck.status";
            if (!sender.hasPermission(permission)) return noPermission(sender);
            Player player = findPlayer(args[1]);
            if (player == null) {
                sender.sendMessage(message("player-offline"));
                return true;
            }
            TapCheckSession session = sessions.get(player.getUniqueId());
            if (session == null) {
                sender.sendMessage(message("no-session"));
                return true;
            }
            if ("logs".equals(sub)) {
                if (!getConfig().getBoolean("logs.enabled", true)) {
                    sender.sendMessage(color("&cTapCheck log collection is disabled."));
                    return true;
                }
                sendLogRequest(player, session);
                sender.sendMessage(message("logs-requested"));
                return true;
            }
            sender.sendMessage(formatStatus(player, session, "mods".equals(sub)));
            return true;
        }
        if ("clearlogs".equals(sub)) {
            if (!sender.hasPermission("tapcheck.logs.view")) return noPermission(sender);
            Path directory = logRoot.resolve(args[1]);
            try {
                UUID uuid = UUID.fromString(args[1]);
                directory = logRoot.resolve(uuid.toString());
            } catch (IllegalArgumentException ignored) {
                OfflinePlayer offline = Bukkit.getOfflinePlayer(args[1]);
                if (offline.getUniqueId() != null) directory = logRoot.resolve(offline.getUniqueId().toString());
            }
            Path finalDirectory = directory;
            Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
                try (var paths = Files.walk(finalDirectory)) {
                    paths.sorted(Comparator.reverseOrder()).forEach(path -> {
                        try { Files.deleteIfExists(path); } catch (IOException ignored) {}
                    });
                    sender.sendMessage(color("&aStored TapCheck logs cleared."));
                } catch (IOException exception) {
                    sender.sendMessage(color("&cNo stored TapCheck logs found."));
                }
            });
            return true;
        }
        sender.sendMessage(color("&cUsage: /tapcheck <mods|logs|status|reload|info|clearlogs>"));
        return true;
    }

    private String formatStatus(Player player, TapCheckSession session, boolean includeMods) {
        StringBuilder output = new StringBuilder();
        output.append(color("&8&m--------------------")).append('\n');
        output.append(color("&bTAPCHECK")).append('\n');
        output.append(color("&fPlayer: &7")).append(player.getName()).append('\n');
        output.append(color("&fUUID: &7")).append(player.getUniqueId()).append('\n');
        output.append(color("&fStatus: &7")).append(statusText(session.status())).append('\n');
        output.append(color("&fClient: &7")).append(session.clientVersion()).append('\n');
        output.append(color("&fBlacklisted: &7")).append(session.blacklisted() ? "&eYes" : "&aNo").append('\n');
        if (includeMods) {
            output.append(color("&fInstalled Mods (&7")).append(session.mods().size()).append(color("&f):")).append('\n');
            session.mods().stream().sorted(Comparator.comparing(ReportedMod::id))
                    .forEach(mod -> output.append(color("&7• &f")).append(mod.id()).append(" &8(").append(mod.version()).append(")\n"));
        }
        output.append(color("&8&m--------------------"));
        return output.toString();
    }

    private String statusText(TapCheckStatus status) {
        return switch (status) {
            case VERIFIED -> color("&a✅ VERIFIED");
            case FLAGGED -> color("&e⚠ FLAGGED");
            case VERIFYING -> color("&e… VERIFYING");
            case NOT_VERIFIED -> color("&c❌ NOT VERIFIED");
            case DISCONNECTED -> color("&7DISCONNECTED");
        };
    }

    private boolean noPermission(CommandSender sender) {
        sender.sendMessage(color("&cYou do not have permission to use that command."));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("mods", "logs", "status", "reload", "info", "clearlogs").stream()
                    .filter(value -> value.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();
        }
        if (args.length == 2 && Set.of("mods", "logs", "status").contains(args[0].toLowerCase(Locale.ROOT))) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName).sorted().toList();
        }
        return List.of();
    }
}