# TapCheck build notes

This package contains two independent deliverables:

- `mod/` — Fabric client source and the compiled Fabric jar
- `plugin/` — Paper server source and the compiled Paper jar

The server defaults to optional verification (`verification.require-mod: false`)
and does not automatically ban players. The client-side log collector is
hard-coded to the Minecraft `logs/latest.log` file and enforces a 10 MiB upper
bound even if a server requests a larger value.

The Fabric jar is compiled against 1.21.4 and declares `>=1.21.4 <1.22`.
Because Fabric API and intermediary mappings are runtime dependencies, install
the matching Fabric API for the specific Minecraft version being played.