package dev.tapcheck.plugin.api;

import org.bukkit.entity.Player;

public final class TapCheckUnverifyEvent extends TapCheckEvent {
    private final Player player;
    public TapCheckUnverifyEvent(Player player) { this.player = player; }
    public Player getPlayer() { return player; }
}