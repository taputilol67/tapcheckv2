package dev.tapcheck.fabric;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class ModScanner {
    private ModScanner() {}

    public static List<ReportedMod> scan() {
        List<ReportedMod> mods = new ArrayList<>();
        for (ModContainer container : FabricLoader.getInstance().getAllMods()) {
            String id = container.getMetadata().getId();
            String name = container.getMetadata().getName();
            String version = container.getMetadata().getVersion().getFriendlyString();
            mods.add(new ReportedMod(id, name, version, "fabric"));
        }
        return mods.stream().sorted(Comparator.comparing(ReportedMod::id)).toList();
    }

    public record ReportedMod(String id, String name, String version, String loader) {}
}