# TapCheck Fabric client

The client mod is intentionally passive. It does nothing on servers that do
not respond on the `tapcheck:main` channel. It reports Fabric mod metadata only
after a valid server handshake, and it sends `latest.log` only after a
server-side `/tapcheck logs <player>` request.

This build is compiled against Minecraft 1.21.4 and declares the Fabric
Minecraft range `>=1.21.4 <1.22`, covering the requested 1.21.4–1.21.11
range when the installed Fabric Loader/Fabric API satisfy the declared
dependencies. The networking and scanner code is kept on stable Fabric API
interfaces so no per-version mixins are needed.

## Build

```bash
./gradlew build
```

The output is `build/libs/tapcheck-fabric-1.0.0.jar`.

## Client settings

The config file is `config/tapcheck.json`. A vanilla settings screen can be
opened with the unbound **Open TapCheck settings** key. Both mod sharing and
log requests are enabled by default and can be disabled by the player.