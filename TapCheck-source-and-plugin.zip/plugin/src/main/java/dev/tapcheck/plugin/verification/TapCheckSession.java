package dev.tapcheck.plugin.verification;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class TapCheckSession {
    private final UUID uuid;
    private final String challenge;
    private TapCheckStatus status = TapCheckStatus.VERIFYING;
    private final List<ReportedMod> mods = new ArrayList<>();
    private boolean responseReceived;
    private boolean blacklisted;
    private String clientVersion = "unknown";
    private String originalListName;
    private long verifiedSeconds;
    private boolean rewardsDisabled;
    private String incomingLogName;
    private ByteArrayOutputStream incomingLog;
    private final Map<Integer, byte[]> logChunks = new LinkedHashMap<>();

    public TapCheckSession(UUID uuid, String challenge) {
        this.uuid = uuid;
        this.challenge = challenge;
    }

    public UUID uuid() { return uuid; }
    public String challenge() { return challenge; }
    public TapCheckStatus status() { return status; }
    public void status(TapCheckStatus status) { this.status = status; }
    public List<ReportedMod> mods() { return List.copyOf(mods); }
    public void replaceMods(List<ReportedMod> values) {
        mods.clear();
        mods.addAll(values);
    }
    public boolean responseReceived() { return responseReceived; }
    public void responseReceived(boolean value) { responseReceived = value; }
    public boolean blacklisted() { return blacklisted; }
    public void blacklisted(boolean value) { blacklisted = value; }
    public String clientVersion() { return clientVersion; }
    public void clientVersion(String value) { clientVersion = value; }
    public String originalListName() { return originalListName; }
    public void originalListName(String value) { originalListName = value; }
    public long verifiedSeconds() { return verifiedSeconds; }
    public void addVerifiedSecond() { verifiedSeconds++; }
    public void resetVerifiedSeconds() { verifiedSeconds = 0; }
    public boolean rewardsDisabled() { return rewardsDisabled; }
    public void rewardsDisabled(boolean value) { rewardsDisabled = value; }
    public String incomingLogName() { return incomingLogName; }
    public void beginLog(String name) {
        incomingLogName = name;
        incomingLog = new ByteArrayOutputStream();
        logChunks.clear();
    }
    public void addLogChunk(int sequence, byte[] bytes) {
        if (incomingLog != null) logChunks.put(sequence, bytes);
    }
    public byte[] finishLog() {
        if (incomingLog == null) return new byte[0];
        for (byte[] chunk : logChunks.values()) incomingLog.writeBytes(chunk);
        byte[] result = incomingLog.toByteArray();
        incomingLog = null;
        logChunks.clear();
        return result;
    }
}