package dev.tapcheck.plugin.verification;

public enum TapCheckStatus {
    NOT_VERIFIED,
    VERIFYING,
    VERIFIED,
    FLAGGED,
    DISCONNECTED
}