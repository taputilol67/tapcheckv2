package dev.tapcheck.plugin.api;

import dev.tapcheck.plugin.verification.ReportedMod;
import org.bukkit.entity.Player;

public final class TapCheckModDetectedEvent extends TapCheckEvent {
    private final Player player;
    private final ReportedMod mod;
    public TapCheckModDetectedEvent(Player player, ReportedMod mod) {
        this.player = player;
        this.mod = mod;
    }
    public Player getPlayer() { return player; }
    public ReportedMod getMod() { return mod; }
}