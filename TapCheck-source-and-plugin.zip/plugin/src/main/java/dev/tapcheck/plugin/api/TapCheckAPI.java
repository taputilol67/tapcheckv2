package dev.tapcheck.plugin.api;

import dev.tapcheck.plugin.TapCheckPlugin;
import dev.tapcheck.plugin.verification.ReportedMod;
import dev.tapcheck.plugin.verification.TapCheckSession;
import dev.tapcheck.plugin.verification.TapCheckStatus;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.UUID;

public final class TapCheckAPI {
    private static TapCheckPlugin plugin;

    private TapCheckAPI() {}

    public static void bind(TapCheckPlugin value) {
        plugin = value;
    }

    public static boolean isVerified(Player player) {
        return getStatus(player) == TapCheckStatus.VERIFIED;
    }

    public static TapCheckStatus getStatus(Player player) {
        TapCheckSession session = plugin == null ? null : plugin.session(player.getUniqueId());
        return session == null ? TapCheckStatus.DISCONNECTED : session.status();
    }

    public static List<ReportedMod> getMods(Player player) {
        TapCheckSession session = plugin == null ? null : plugin.session(player.getUniqueId());
        return session == null ? List.of() : session.mods();
    }

    public static boolean hasMod(Player player, String modId) {
        return getMods(player).stream().anyMatch(mod -> mod.id().equalsIgnoreCase(modId));
    }

    public static boolean hasBlacklistedMod(Player player) {
        TapCheckSession session = plugin == null ? null : plugin.session(player.getUniqueId());
        return session != null && session.blacklisted();
    }

    public static UUID getPlayerUUID(Player player) {
        return player.getUniqueId();
    }
}