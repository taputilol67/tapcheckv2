package dev.tapcheck.plugin.api;

import org.bukkit.entity.Player;
import java.nio.file.Path;

public final class TapCheckLogReceivedEvent extends TapCheckEvent {
    private final Player player;
    private final Path path;
    public TapCheckLogReceivedEvent(Player player, Path path) {
        this.player = player;
        this.path = path;
    }
    public Player getPlayer() { return player; }
    public Path getPath() { return path; }
}