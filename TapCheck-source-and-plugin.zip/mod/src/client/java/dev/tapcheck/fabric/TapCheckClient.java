package dev.tapcheck.fabric;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;

public final class TapCheckClient implements ClientModInitializer {
    private static final Gson GSON = new Gson();
    private static TapCheckConfig config;
    private static KeyBinding configKey;
    private static String activeChallenge;
    private static boolean serverSupportsTapCheck;

    @Override
    public void onInitializeClient() {
        config = TapCheckConfig.load();
        configKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.tapcheck.open_config", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "category.tapcheck"));
        registerNetworking();
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (configKey.wasPressed()) client.setScreen(new TapCheckConfigScreen(client.currentScreen));
        });
    }

    public static TapCheckConfig config() {
        return config;
    }

    private void registerNetworking() {
        ClientPlayNetworking.registerGlobalReceiver(TapCheckProtocol.CHANNEL, (client, handler, buf, responseSender) -> {
            byte[] bytes;
            try {
                bytes = buf.readByteArray(512_000);
            } catch (RuntimeException exception) {
                return;
            }
            String payload = new String(bytes, StandardCharsets.UTF_8);
            client.execute(() -> handleServerMessage(client, payload));
        });
    }

    private static void handleServerMessage(MinecraftClient client, String payload) {
        final JsonObject message;
        try {
            message = JsonParser.parseString(payload).getAsJsonObject();
        } catch (RuntimeException exception) {
            return;
        }
        String action = string(message, "action", "");
        if (TapCheckProtocol.HELLO.equals(action)) {
            int protocol = number(message, "protocol", 0);
            String challenge = string(message, "challenge", "");
            if (protocol != TapCheckProtocol.VERSION || challenge.isBlank()) return;
            activeChallenge = challenge;
            serverSupportsTapCheck = true;
            sendResponse(challenge);
            if (config.modSharingEnabled()) sendModList(challenge);
            return;
        }
        if (TapCheckProtocol.LOG_REQUEST.equals(action)) {
            if (!serverSupportsTapCheck || !config.logRequestsEnabled()) return;
            if (!activeChallenge.equals(string(message, "challenge", ""))) return;
            long maxBytes = Math.min(number(message, "maxBytes", 10L * 1024L * 1024L),
                    10L * 1024L * 1024L);
            sendLatestLog(maxBytes);
            return;
        }
        if (TapCheckProtocol.STATUS.equals(action)) {
            String status = string(message, "status", "UNKNOWN");
            if (client.player != null) {
                client.player.sendMessage(Text.literal("TapCheck: " + status), true);
            }
        }
    }

    private static void sendResponse(String challenge) {
        JsonObject response = base(TapCheckProtocol.RESPONSE, challenge);
        response.addProperty("protocol", TapCheckProtocol.VERSION);
        response.addProperty("clientVersion", "1.0.0");
        send(response);
    }

    private static void sendModList(String challenge) {
        JsonObject message = base(TapCheckProtocol.MOD_LIST, challenge);
        JsonArray mods = new JsonArray();
        for (ModScanner.ReportedMod mod : ModScanner.scan()) {
            JsonObject item = new JsonObject();
            item.addProperty("id", mod.id());
            item.addProperty("name", mod.name());
            item.addProperty("version", mod.version());
            item.addProperty("loader", mod.loader());
            mods.add(item);
        }
        message.add("mods", mods);
        send(message);
    }

    private static void sendLatestLog(long maxBytes) {
        try {
            byte[] log = LogCollector.readLatestLog(maxBytes);
            JsonObject begin = new JsonObject();
            begin.addProperty("action", TapCheckProtocol.LOG_BEGIN);
            begin.addProperty("file", "latest.log");
            begin.addProperty("size", log.length);
            send(begin);
            int sequence = 0;
            for (int offset = 0; offset < log.length; offset += 12_000) {
                int end = Math.min(log.length, offset + 12_000);
                byte[] chunk = java.util.Arrays.copyOfRange(log, offset, end);
                JsonObject packet = new JsonObject();
                packet.addProperty("action", TapCheckProtocol.LOG_CHUNK);
                packet.addProperty("file", "latest.log");
                packet.addProperty("sequence", sequence++);
                packet.addProperty("data", Base64.getEncoder().encodeToString(chunk));
                send(packet);
            }
            JsonObject finish = new JsonObject();
            finish.addProperty("action", TapCheckProtocol.LOG_END);
            finish.addProperty("file", "latest.log");
            finish.addProperty("chunks", sequence);
            send(finish);
        } catch (IOException exception) {
            JsonObject error = new JsonObject();
            error.addProperty("action", TapCheckProtocol.LOG_ERROR);
            error.addProperty("message", "latest.log is unavailable");
            send(error);
        }
    }

    private static JsonObject base(String action, String challenge) {
        JsonObject object = new JsonObject();
        object.addProperty("action", action);
        object.addProperty("challenge", challenge);
        return object;
    }

    private static void send(JsonObject object) {
        PacketByteBuf buffer = net.fabricmc.fabric.api.networking.v1.PacketByteBufs.create();
        buffer.writeByteArray(GSON.toJson(object).getBytes(StandardCharsets.UTF_8));
        ClientPlayNetworking.send(TapCheckProtocol.CHANNEL, buffer);
    }

    private static String string(JsonObject object, String key, String fallback) {
        JsonElement value = object.get(key);
        return value == null ? fallback : value.getAsString();
    }

    private static long number(JsonObject object, String key, long fallback) {
        JsonElement value = object.get(key);
        try { return value == null ? fallback : value.getAsLong(); }
        catch (RuntimeException exception) { return fallback; }
    }
}