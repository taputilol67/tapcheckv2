package dev.tapcheck.fabric;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class TapCheckConfigScreen extends Screen {
    private final Screen parent;
    private ButtonWidget sharingButton;
    private ButtonWidget logsButton;

    public TapCheckConfigScreen(Screen parent) {
        super(Text.literal("TapCheck"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 100;
        sharingButton = addDrawableChild(ButtonWidget.builder(sharingText(), button -> {
            TapCheckClient.config().setModSharingEnabled(!TapCheckClient.config().modSharingEnabled());
            TapCheckClient.config().save();
            button.setMessage(sharingText());
        }).dimensions(left, this.height / 2 - 40, 200, 20).build());
        logsButton = addDrawableChild(ButtonWidget.builder(logsText(), button -> {
            TapCheckClient.config().setLogRequestsEnabled(!TapCheckClient.config().logRequestsEnabled());
            TapCheckClient.config().save();
            button.setMessage(logsText());
        }).dimensions(left, this.height / 2 - 10, 200, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), button -> close())
                .dimensions(left, this.height / 2 + 30, 200, 20).build());
    }

    private Text sharingText() {
        return Text.literal("Mod sharing: " + (TapCheckClient.config().modSharingEnabled() ? "ON" : "OFF"));
    }

    private Text logsText() {
        return Text.literal("Log requests: " + (TapCheckClient.config().logRequestsEnabled() ? "ON" : "OFF"));
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(parent);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 80, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Only share information with a TapCheck server after its handshake."),
                width / 2, height / 2 - 62, 0xB0B0B0);
        super.render(context, mouseX, mouseY, delta);
    }
}