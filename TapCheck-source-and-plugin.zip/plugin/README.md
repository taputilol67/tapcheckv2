# TapCheck Paper plugin

TapCheck is an optional verification layer, not a proof that a client is cheat-free.

## Build

```bash
mvn package
```

The output is `target/TapCheck-Paper-1.0.0.jar`. Install it in the server's
`plugins/` directory and restart Paper 1.21.11.

## Protocol and privacy

The plugin uses the `tapcheck:main` plugin channel. It sends a random,
per-connection challenge and accepts mod data only after the client proves the
challenge belongs to the current connection. No current mod list is retained
after disconnecting.

The log command requests only `latest.log` while the player is online. The
client never receives a path from the server and the plugin never attempts to
read the player's computer. Stored logs are written below
`plugins/TapCheck/logs/<uuid>/` and removed according to `logs.retain-days`.

## Commands

- `/tapcheck mods <player>`
- `/tapcheck logs <player>`
- `/tapcheck status <player>`
- `/tapcheck reload`
- `/tapcheck info`
- `/tapcheck clearlogs <uuid-or-name>`

See `src/main/resources/config.yml` for optional verification, blacklist,
rewards, whitelist, and retention settings.