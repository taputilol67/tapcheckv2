package dev.tapcheck.fabric;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class TapCheckConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("tapcheck.json");

    private boolean modSharingEnabled = true;
    private boolean logRequestsEnabled = true;

    public static TapCheckConfig load() {
        if (!Files.exists(FILE)) {
            TapCheckConfig config = new TapCheckConfig();
            config.save();
            return config;
        }
        try {
            TapCheckConfig config = GSON.fromJson(Files.readString(FILE), TapCheckConfig.class);
            return config == null ? new TapCheckConfig() : config;
        } catch (Exception exception) {
            System.err.println("[TapCheck] Could not read config; using safe defaults: " + exception.getMessage());
            return new TapCheckConfig();
        }
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(this), StandardCharsets.UTF_8);
        } catch (IOException exception) {
            System.err.println("[TapCheck] Could not save config: " + exception.getMessage());
        }
    }

    public boolean modSharingEnabled() { return modSharingEnabled; }
    public boolean logRequestsEnabled() { return logRequestsEnabled; }
    public void setModSharingEnabled(boolean value) { modSharingEnabled = value; }
    public void setLogRequestsEnabled(boolean value) { logRequestsEnabled = value; }
}