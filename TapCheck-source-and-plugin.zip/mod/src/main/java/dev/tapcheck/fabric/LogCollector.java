package dev.tapcheck.fabric;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

public final class LogCollector {
    private LogCollector() {}

    public static byte[] readLatestLog(long maxBytes) throws IOException {
        Path logsDirectory = net.fabricmc.loader.api.FabricLoader.getInstance().getGameDir()
                .resolve("logs").normalize();
        Path latest = logsDirectory.resolve("latest.log").normalize();
        if (!latest.startsWith(logsDirectory) || !Files.isRegularFile(latest)) {
            throw new IOException("latest.log is not available");
        }
        long safeLimit = Math.max(1, Math.min(maxBytes, 10L * 1024L * 1024L));
        byte[] all = Files.readAllBytes(latest);
        if (all.length <= safeLimit) return all;
        return Arrays.copyOfRange(all, all.length - (int) safeLimit, all.length);
    }
}