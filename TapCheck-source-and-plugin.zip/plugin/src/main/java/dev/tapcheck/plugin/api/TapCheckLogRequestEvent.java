package dev.tapcheck.plugin.api;

import org.bukkit.entity.Player;

public final class TapCheckLogRequestEvent extends TapCheckEvent {
    private final Player player;
    public TapCheckLogRequestEvent(Player player) { this.player = player; }
    public Player getPlayer() { return player; }
}