package dev.tapcheck.plugin.api;

import org.bukkit.entity.Player;

public final class TapCheckVerifyEvent extends TapCheckEvent {
    private final Player player;
    public TapCheckVerifyEvent(Player player) { this.player = player; }
    public Player getPlayer() { return player; }
}